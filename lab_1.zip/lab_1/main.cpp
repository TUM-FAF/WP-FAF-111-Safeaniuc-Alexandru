#include <windows.h>
LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM) ;
int WINAPI WinMain (HINSTANCE hInstance,
                    HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
     {
     static char szAppName[] = "HelloWin" ;
     HWND        hwnd ;// ���������� ����, �������� ���������� ���������
     MSG         msg ; //main message loop
     WNDCLASSEX  wndclass ; //win clas tip
     UINT        massage;  //tot cu WM
     WPARAM      wParam;
     LPARAM      lParam;
     DWORD       time;
     POINT       pt;

     wndclass.cbSize        = sizeof (wndclass) ;                       //hold the size of WINDCLSSEX in byts
     wndclass.style         = CS_HREDRAW | CS_VREDRAW ;                 //the style of this window class type //redeseneaza cin se schimba x,y
     wndclass.lpfnWndProc   = WndProc ;                                 //a function pointer o the event handler
     wndclass.cbClsExtra    = 0 ;
     wndclass.cbWndExtra    = 0 ;
     wndclass.hInstance     = hInstance ;                               //a handle to the current module
     wndclass.hIcon         = LoadIcon (NULL, IDI_APPLICATION) ;        // cum arata   imaginea linga aplicatie
     wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;            //the cursor for the  client area //IDC_IBEAM  alt cursor
     wndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH) ;   // the color of the client area //wndclass.hbrBackground = (HBRUSH)(COLOR_MENUTEXT);
     wndclass.lpszMenuName  = NULL ;                                    // the menu  for windows in the class
     wndclass.lpszClassName = szAppName ;                               //the name of the window class that is set internaly
     wndclass.hIconSm       = LoadIcon (NULL, IDI_APPLICATION) ;        //the small icon for the window class (right left corner of the window or menu)

     RegisterClassEx (&wndclass) ;                                      //we register the class that we create of this type

     hwnd = CreateWindow (szAppName,         // window class name
		            "lab.nr.1 ",             // window caption
                    WS_OVERLAPPEDWINDOW,     // window style
                    CW_USEDEFAULT,           // initial x position
                    CW_USEDEFAULT,           // initial y position
                    CW_USEDEFAULT,           // initial x size
                    CW_USEDEFAULT,           // initial y size
                    NULL,                    // parent window handle
                    NULL,                    // window menu handle
                    hInstance,               // program instance handle
		            NULL) ;		             // creation parameters
     ShowWindow (hwnd, iCmdShow) ;
     UpdateWindow (hwnd) ;


     //main message loop:
     while (GetMessage (&msg, NULL, 0, 0))
          {
          TranslateMessage (&msg) ;
          DispatchMessage (&msg) ;
          }
     return msg.wParam ;
     }
LRESULT CALLBACK WndProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
     {
     HDC         hdc ;
     PAINTSTRUCT ps ;
     RECT        rect ;
     static int cxChar,cyChar;
     switch (iMsg)
          {
        case WM_CREATE :
                  cxChar=LOWORD(GetDialogBaseUnits());
                  cyChar=HIWORD(GetDialogBaseUnits());
               //PlaySound ("hellowin.wav", NULL, SND_FILENAME | SND_ASYNC) ;//
               //return 0 ;
               //
        case WM_GETMINMAXINFO:
                MINMAXINFO * mmiStruct;
                mmiStruct = (MINMAXINFO*)lParam;

                POINT ptPoint;

                ptPoint.x = 50*cxChar; //Minimum width of the window.
                ptPoint.y = cyChar*6; //Minimum height of the window.
                mmiStruct->ptMinTrackSize = ptPoint;

                    //ptPoint.x = GetSystemMetrics(SM_CXMAXIMIZED); //Maximum width of the window.
                    // ptPoint.y = GetSystemMetrics(SM_CYMAXIMIZED); //Maximum height of the window.
                    //mmiStruct->ptMaxTrackSize = ptPoint;








          case WM_PAINT :
	           hdc = BeginPaint (hwnd, &ps) ;
               GetClientRect (hwnd, &rect) ;
               DrawText (hdc, "Done with Pride and Prejudice by Safeaniuc Alexandru", -1, &rect,
			             DT_SINGLELINE | DT_CENTER | DT_VCENTER) ;
	           EndPaint (hwnd, &ps) ;
               return 0 ;
          case WM_DESTROY :
               PostQuitMessage (0) ;
               return 0 ;
          }
     return DefWindowProc (hwnd, iMsg, wParam, lParam) ;
     }
